# seatlog-python
Small logger for Python, compliant with Seatfrog logging standards.